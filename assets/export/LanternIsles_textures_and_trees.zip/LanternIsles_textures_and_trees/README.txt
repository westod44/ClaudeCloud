Lantern Isles - tileable terrain textures and tree/bush sprites, as currently used in the game.
These are the hand-made replacements imported from assets/custom/source/ by tools/import_custom.py.

terrain_tileable/  384x384 px, tile seamlessly; sampled in world space over 4x4 isometric tiles (96 texels per tile).
trees_and_bushes/sheets/  game sprite sheets: 3 leaf-flutter frames left to right; *_shadow.png is the separate shadow layer.
trees_and_bushes/single_frame/  frame 0 only: body alone, and body composited over its shadow.
Anchor = the pixel that sits on the object's ground point (trunk base).

| name | description | frame size | frames | anchor |
|---|---|---|---|---|
| oak_1 | Oak | 200x124 | 3 | (68, 110) |
| oak_2 | Oak | 200x121 | 3 | (57, 107) |
| oak_3 | Beech | 206x139 | 3 | (68, 124) |
| oak_4 | Beech | 199x138 | 3 | (62, 123) |
| maple_1 | Maple (autumn) | 180x127 | 3 | (61, 112) |
| maple_2 | Maple (autumn) | 197x129 | 3 | (62, 114) |
| aspen_1 | Aspen (golden) | 151x124 | 3 | (31, 109) |
| birch_1 | Birch | 173x132 | 3 | (40, 117) |
| birch_2 | Birch | 161x138 | 3 | (35, 124) |
| pine_1 | Pine | 192x162 | 3 | (52, 137) |
| pine_2 | Pine | 181x151 | 3 | (53, 125) |
| pine_3 | Pine | 195x166 | 3 | (55, 136) |
| pine_snow_1 | Snowy pine | 173x145 | 3 | (49, 120) |
| pine_snow_2 | Snowy pine | 181x155 | 3 | (51, 127) |
| palm_1 | Palm | 228x142 | 3 | (74, 128) |
| palm_2 | Palm | 221x139 | 3 | (51, 128) |
| dead_tree | Dead tree | 201x133 | 3 | (68, 118) |
| bush_1 | Shrub | 70x45 | 3 | (24, 34) |
| bush_2 | Shrub | 68x55 | 3 | (25, 40) |
| berry_bush | Berry bush (forage) | 69x48 | 3 | (23, 34) |
| fern_1 | Fern | 75x49 | 3 | (31, 31) |
| fern_2 | Fern | 81x49 | 3 | (35, 30) |
